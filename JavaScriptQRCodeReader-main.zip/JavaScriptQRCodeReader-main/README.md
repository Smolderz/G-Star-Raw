# JavaScript QR Code Reader
Create a QR Code Scanner With Vanilla JavaScript and the Built-In Barcode Detector API

Learn more about how this code works [here](https://www.jsnow.io/p/javascript/creating-a-real-time-qr-code-scanner-with-vanilla-javascript-part-1)
